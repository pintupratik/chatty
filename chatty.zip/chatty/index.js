var express = require('express');
var app = express();
var http = require('http').Server(app);
var io = require('socket.io')(http);

app.use('/images', express.static(__dirname + '/assets/images'));
app.use('/assets/fonts', express.static(__dirname + '/assets/fonts'));
app.use('/assets/vendor', express.static(__dirname + '/assets/vendor'));
app.use('/html/cssfiles', express.static(__dirname + '/html/cssfiles'));

http.listen(3000,function(){
    console.log("Server started at 3000 port");
});

var client=0;
io.on('connection',function(socket){
 client++;
 io.sockets.emit('broadcast',{description: client + 'clients connected'});
 socket.on('disconnect', function() {
    client--;
    io.sockets.emit('broadcast',{ description: client + 'clients connected'});
 });
});

app.get('/',function(req,res){
    res.sendFile(__dirname+'/html/login.html');

});

app.get('/chathome',function(req,res){
    res.writeHead(301,{'location':"http://localhost:4000"});
    res.end();

});

app.get('/login', function(req,res){
    var username = req.query.username;
    var pwd =req.query.pass;
    //var l = login(username,pwd);
    //if(l===true){
        res.redirect('/chathome');    //res.write("Welcome "+username+ " to the chatty home page");
//}else{
 //   res.write("You are a stranger!!!");
//}
    res.end();
});



function login(username,pwd){
    console.log("Login Clicked");
    if(username==="Pratik"){
    return true;
    }
    else{
        return false;
    }
};