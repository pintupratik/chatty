var express = require('express');
var socket = require('socket.io');

var app = express();

var server = app.listen(4000, function(){
    console.log('listening to port 4000');
});

app.use('/images', express.static(__dirname + '/assets/images'));
app.use('/assets/fonts', express.static(__dirname + '/assets/fonts'));
app.use('/assets/vendor', express.static(__dirname + '/assets/vendor'));
app.use('/html/cssfiles', express.static(__dirname + '/html/cssfiles'));
app.use(express.static('public'));

app.get('/',function(req,res){
    res.sendFile(__dirname+'/html/chathome.html');

});

var io = socket(server);

io.on('connection',(socket) => {
    console.log('socket connected',socket.id);
    socket.on('chat',function(data){
        io.sockets.emit('chat',data);
    });
    socket.on('typing',function(data){
        socket.broadcast.emit('typing',data);
    });
});